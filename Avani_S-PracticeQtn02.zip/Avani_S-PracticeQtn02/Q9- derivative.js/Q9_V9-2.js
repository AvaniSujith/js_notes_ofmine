function derivative(num){
    let h = 0.001;
    
}

