// Write a program to check if the given number is a perfect square or not?

// function square(num){
//     if(num < 0){
//         console.log("Invalid");
//     }else{
//         let remainder = num%2;
//         let guessNum = 0;
        
//         if(remainder == 0){
//         guessNum = num /2;
//         }else{
//         let value = num/2;

//         while(value > 1){
//             value = value - 1;
//         }
//         console.log(value)

//     }
//     }

// }


// let a = 2.45;
// let b = a - 0.1;

function division(num){
    let value = 0;
while(value > 1){
    value = num - 1;

}
  console.log(value);
}

division(9.6);

