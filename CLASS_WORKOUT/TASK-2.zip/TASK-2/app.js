const SYMBOLS = [
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
    'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z'
];

// Corrected utility function
const getElement = id => document.getElementById(id);

const showPage = pageId => {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    getElement(pageId).classList.add('active');
};

// Populate symbol count dropdown
const populateSymbolCountDropdown = () => {
    const symbolCountSelect = getElement('symbol-count');
    symbolCountSelect.innerHTML = '';
    for (let i = 2; i <= SYMBOLS.length; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = `${i} Symbols`;
        symbolCountSelect.appendChild(option);
    }
};

// Convert number to base
const convertToBase = (number, base) => {
    if (number === 0) return SYMBOLS[0];

    let result = '';
    while (number > 0) {
        result = SYMBOLS[number % base] + result;
        number = Math.floor(number / base);
    }
    return result;
};

// Generate and display pattern
const generateSinglePattern = (number, base) => {
    const patternOutput = getElement('pattern-output');
    patternOutput.innerHTML = '';

    const patternItem = document.createElement('div');
    patternItem.classList.add('pattern-item');
    patternItem.textContent = `Number: ${number}, Base ${base} Pattern: ${convertToBase(number, base)}`;
    patternOutput.appendChild(patternItem);
};

// Initialize app
const initNumberPatternApp = () => {
    populateSymbolCountDropdown();

    // Menu dropdown toggle
    getElement('menu-btn').addEventListener('click', () => {
        const dropdownContent = getElement('dropdown-content');
        dropdownContent.classList.toggle('show');
    });

    // Navigation event listeners
    getElement('start-btn').addEventListener('click', () => {
        const selectedBase = +getElement('symbol-count').value;
        if (!selectedBase || selectedBase < 2) {
            alert('Please select a valid symbol count.');
            return;
        }
        window.selectedBase = selectedBase;
        showPage('selection-page');
    });

    // Pattern page navigation
    document.querySelector('.pattern button').addEventListener('click', () => {
        showPage('pattern-input-page');
    });

    // Sequence page navigation
    document.querySelector('.sequence button').addEventListener('click', () => {
        showPage('sequence-input-page');
    });

    // Pattern generation
    document.querySelector('#pattern-input-page .btn').addEventListener('click', () => {
        const patternNumber = +getElement('pattern-number').value;
        if (isNaN(patternNumber) || patternNumber < 0) {
            alert('Please enter a valid positive number.');
            return;
        }
        generateSinglePattern(patternNumber, window.selectedBase);
        showPage('sequence-output-page');
    });

    // Home and back buttons
    getElement('home-btn').addEventListener('click', () => {
        showPage('welcome-page');
    });

    getElement('back-btn').addEventListener('click', () => {
        showPage('selection-page');
    });

    // Instructions page
    getElement('instructions-btn').addEventListener('click', () => {
        showPage('instructions-page');
    });

    getElement('close-instructions-btn').addEventListener('click', () => {
        showPage('welcome-page');
    });
};

// Load the app when DOM is ready

document.addEventListener('DOMContentLoaded', initNumberPatternApp);


